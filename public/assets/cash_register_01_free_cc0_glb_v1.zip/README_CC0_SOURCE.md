# Cash Register 01 - CC0 Source Notes

Prepared by Eclair Assets on 2026-05-27 JST.

## Included Model

- `cash_register_01_cc0_clip_ready_v1.glb`

## Source

- Source asset: Cash Register 01 / Poly Haven
- Source URL: https://polyhaven.com/a/CashRegister_01
- Author: Joe Seabuhr
- Source license: CC0
- License page: https://polyhaven.com/license
- License checked: 2026-05-27

## Usage Summary

According to Poly Haven's license page, Poly Haven assets are licensed as CC0.

- Commercial use allowed
- Non-commercial use allowed
- Modification allowed
- Redistribution allowed
- Credit not required

Credit is not required, but crediting Poly Haven and the source author is appreciated.

## Eclair Assets Notes

This package is not an official Poly Haven product.

Eclair Assets downloaded the Poly Haven glTF source, converted it into a compact GLB package, and added source/license notes for easier use in illustration, manga, layout, and scene-dressing workflows.

Poly Haven logos, website thumbnails, page screenshots, and example renders are not included.

## Clip Studio Paint

In CLIP STUDIO PAINT, GLB files can usually be imported by dragging and dropping the file onto the canvas.

Display may vary depending on the app and material settings.

